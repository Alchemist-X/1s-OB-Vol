# PM-BTC5min-盘口监听

Polymarket BTC 5 分钟涨跌市场的订单簿数据采集系统——从 1 秒轮询到 150 req/s 极限并发。

---

## 1. 项目背景

Polymarket 上有一类 BTC 5 分钟涨跌预测市场（"Bitcoin Up or Down"），每 5 分钟一期，基于 Chainlink BTC/USD 数据流结算。这类市场流动性集中、生命周期短（5 分钟），非常适合高频订单簿数据研究。

**目标**：采集完整的挂单簿（所有价位）、成交数据，尽可能高频率，直到市场结算。

---

## 2. 探索历程

### 2.1 第一步：多市场 1 秒轮询（monitor.py）

**需求**：同时监听 3 个 BTC 5 分钟市场，每秒采集全量订单簿 + 成交数据。

**实现**：
- 新建 `monitor.py`，支持多 URL 输入
- REST 轮询 `/book`（1 秒间隔） + WebSocket 监听 `last_trade_price` 成交事件
- SQLite 存储 3 张表：
  - `pm_sports_market_1s`：每秒 L1 + 价差 + 深度 + 成交量汇总
  - `pm_orderbook_full_1s`：每秒完整订单簿（**所有价位**，非仅 top 5）
  - `pm_trades_raw`：WebSocket 原始成交事件
- 每 30 秒检查 Gamma API 的 `resolved` 状态，全部结算后自动停止
- 404 智能处理：已结算市场不重试，连续 10 次失败暂停轮询

**结果**（3 市场同时监听，20 秒有效数据）：
| 市场 | 快照 | 订单簿行数 | 最大价位深度 | 成交 |
|------|------|-----------|------------|------|
| 1:25-1:30AM (已结算) | 20 | 0 | — | 0 |
| 1:30-1:35AM | 20 | 1,342 | 59 级 | 274 |
| 1:35-1:40AM | 20 | 1,702 | 44 级 | 8 |

### 2.2 第二步：单市场 600 秒深度采集

**需求**：对单个市场 (1:45-1:50AM) 采集 600 秒（10 分钟）数据。

给 `monitor.py` 添加了 `-d/--duration` 参数。

**结果**（600 秒，1 秒轮询）：
| 指标 | 数值 |
|------|------|
| 快照数 | 600（精确 600 秒） |
| 订单簿总行数 | 50,053 |
| 最大价位深度 | **74 级** |
| 成交总笔数 | 1,857 |
| 订单簿深度变化 | 从 24b/25a → 高峰 74b/63a |
| 成交爆发 | 06:45 起 300-500 笔/分钟 |
| 价差 | 68% 时间 spread = 1¢ |

### 2.3 第三步：API 极限性能测试（api-bench/）

**需求**：测试 Polymarket CLOB REST API 的真实吞吐上限。

**官方限制**（[docs](https://docs.polymarket.com/quickstart/introduction/rate-limits)）：
- `/book`：1500 req / 10s = **150 req/s**
- Cloudflare 对超限请求采用 **throttle（延迟排队）** 而非 reject

**测试方法**：用 `asyncio` + `aiohttp`，从 1 到 300 并发递增，每级持续 10 秒。

**关键结果**：

| 并发数 | 成功 RPS | 429 错误 | 状态 |
|--------|---------|---------|------|
| 1 | 2.8/s | 0 | RTT 瓶颈（~340ms） |
| 5 | 14.6/s | 0 | 线性提升 |
| 20 | 60.4/s | 0 | 线性提升 |
| **50** | **150.1/s** | **0** | **精确命中上限，零 429** |
| 100 | 191.3/s | 2,496 | 突破上限，57% 被 429 |
| 300 | 203.0/s | 9,096 | 82% 被 429 |

**发现**：
1. **并发 50 = 150/s 是无惩罚的绝对上限**
2. 可以突破到 ~200/s，但代价是大量 429 拒绝
3. 单连接上限仅 ~2.8/s（受 340ms RTT 限制）
4. `/midprice` 走独立限流桶，可达 **897/s**（零 429）

### 2.4 第四步：自动发现 + 150 req/s 极限采集（auto_monitor.py）

**需求**：自动发现当前运行的 BTC 5 分钟市场，用 50 并发（~150 req/s）全速采集。

**市场发现算法**：
```
BTC 5 分钟市场 slug = btc-updown-5m-{unix_timestamp}
unix_timestamp 是 300 秒的整数倍

1. 取当前 Unix 时间，对齐到 300 秒边界
2. 构造 slug：btc-updown-5m-{base}, btc-updown-5m-{base+300}, ...
3. 调用 Gamma API /events?slug=<slug> 验证
4. 取第一个未结算的市场
```

**架构**：
```
50 个 aiohttp 并发 worker → /book 背靠背请求
                           ↓
                    asyncio.Queue (ms 时间戳)
                           ↓
WebSocket trades ──→ DB Writer (每秒批量刷入)
                           ↓
                    SQLite WAL (snap_id 关联)
```

**DB Schema**（ms 精度，snap_id 关联）：
- `pm_snapshot`：每个 API 响应一行（snap_id, ts_ms, L1, 延迟）
- `pm_ob_level`：完整订单簿按 snap_id 关联（WITHOUT ROWID 优化）
- `pm_trades_raw`：WebSocket 成交事件

**结果**（300 秒，50 并发）：

| 指标 | 数值 |
|------|------|
| 自动发现 | "Bitcoin Up or Down - Feb 13, 4:30-4:35AM ET"（1 秒完成） |
| 快照总数 | **31,434** |
| 活跃期吞吐 | **146.6 req/s** |
| 订单簿行数 | **1,962,381**（~200 万行） |
| 成交笔数 | 543 |
| 延迟 | p50=315ms, p95=395ms, p99=459ms |
| DB 文件大小 | **59.8 MB** |
| 吞吐稳定性 | 20 个 10 秒窗口全部 144-148/s |

---

## 3. 文件清单

```
1s-OB/
├── auto_monitor.py      # 自动发现 + 150/s 极限采集（最新）
├── monitor.py           # 多市场 1s 轮询监听
├── recorder.py          # 原始单市场录制器
├── resolve.py           # URL → market_id 解析
├── db.py                # SQLite schema (原始版)
├── export_json.py       # SQLite → replay.json 导出
├── player.html          # 浏览器回放播放器
├── config.py            # API URL 配置
├── main.py              # CLI 入口
├── requirements.txt     # websocket-client, requests
└── data/
    ├── btc-auto_20260213T093317/     # 60 MB — auto_monitor 150/s 采集
    ├── btc-monitor_20260213T063946/  # 14 MB — 600s 1/s 采集
    ├── btc-monitor_20260213T063403/  #  1 MB — 3 市场同时监听
    ├── lol-tsw-mvk-.../              # 200 KB — 电竞测试
    └── nba-gsw-phx-.../              #  48 KB — NBA 测试

api-bench/
├── bench.py             # API 极限性能测试脚本
├── results.json         # 测试结果 JSON
├── requirements.txt     # aiohttp, requests
└── README.md
```

---

## 4. 使用方法

### 自动发现 + 极限采集（推荐）
```bash
cd 1s-OB
pip install aiohttp websocket-client requests

# 自动找到下一个 BTC 5 分钟市场，50 并发采集 5 分钟
python3 auto_monitor.py

# 自定义参数
python3 auto_monitor.py -c 50 -d 300    # 50 并发，300 秒
python3 auto_monitor.py -c 1  -d 600    # 单连接，600 秒（省资源）
```

### 多市场 1 秒轮询
```bash
# 指定 URL，1 秒间隔，直到结算
python3 monitor.py \
  'https://polymarket.com/event/btc-updown-5m-...' \
  'https://polymarket.com/event/btc-updown-5m-...'

# 指定时长
python3 monitor.py -d 600 'https://polymarket.com/event/btc-updown-5m-...'
```

### API 性能测试
```bash
cd api-bench
pip install aiohttp requests
python3 bench.py
```

---

## 5. 关键结论

| 问题 | 结论 |
|------|------|
| API 速率上限 | `/book` = 150 req/s（50 并发），实测零 429 |
| 能否突破上限 | 可以到 ~200/s，但 50%+ 请求被 429 拒绝 |
| 单连接上限 | ~2.8 req/s（受 ~340ms RTT 限制） |
| 最快端点 | `/midprice` 可达 897/s（独立限流桶） |
| 数据更新频率 | 订单簿实际变化频率远低于 150/s，但高频采集能捕获微秒级变化 |
| 推荐生产配置 | 50 并发 = 146/s，DB ~60 MB/5 分钟 |
| 市场发现 | slug = `btc-updown-5m-{300 秒对齐的 Unix 时间戳}`，1 秒定位 |

---

## 6. 数据量参考

| 采集模式 | 5 分钟数据量 | 快照数 | OB 行数 |
|----------|-------------|--------|---------|
| 1 req/s（单连接） | ~14 MB | 300 | ~25,000 |
| 146 req/s（50 并发） | ~60 MB | 31,000+ | ~2,000,000 |
