# Polymarket 盘口数据采集与回放工具箱

对 Polymarket 预测市场进行多粒度订单簿（Order Book）采集——从 5 秒低频到 150 次/秒高频——数据落库 SQLite，支持导出 `replay.json` 并在浏览器中回放动画。

## 快速开始

```bash
pip install -r requirements.txt
```

依赖：`requests`、`websocket-client`、`aiohttp`。

### 三种采集模式

```bash
# 模式 1：通用单市场录制（可调间隔/Top-N）
python3 main.py record https://polymarket.com/event/lol-tsw-mvk-2026-02-06 -d 600 -i 1 -e

# 模式 2：多市场全量盘口监听（1s 间隔，直到结算）
python3 monitor.py https://polymarket.com/event/btc-updown-5m-1770965100

# 模式 3：BTC 5min 自动发现 + 高频采集（~150/s）
python3 auto_monitor.py -d 300
```

### 导出与回放

```bash
# 导出任意采集目录为回放文件（自动识别 schema）
python3 main.py export data/btc-updown-5m-1770965100_20260213T063946

# 浏览器打开 player.html，拖入 replay.json 即可回放
```

---

## 采集模式详解

### 模式 1：`main.py record` — 通用单市场录制

适合任意 Polymarket 市场（体育、政治、加密等），可自定义采样间隔和档位数。

```
python3 main.py record <url> [选项]
```

| 参数 | 缩写 | 说明 | 默认值 |
|------|------|------|--------|
| `url` | — | Polymarket 赛事链接（必填） | — |
| `--duration` | `-d` | 录制时长（秒） | 300 |
| `--interval` | `-i` | 采样间隔（秒） | 5.0 |
| `--top` | `-t` | 记录前 N 档挂单 | 5 |
| `--output` | `-o` | 数据输出目录 | `./data` |
| `--export` | `-e` | 录完自动导出 `replay.json` | 否 |

**示例：**

```bash
# 录制 10 分钟，每秒采样，自动导出回放文件
python3 main.py record https://polymarket.com/event/nba-gsw-phx-2026-02-05 \
  -d 600 -i 1 -e

# 录制 3 分钟，每 10 秒采样，记录前 3 档
python3 main.py record https://polymarket.com/event/lol-tsw-mvk-2026-02-06 \
  -d 180 -i 10 -t 3
```

### 模式 2：`monitor.py` — 多市场全量盘口监听

针对多个市场同时录制**全部价位级别**的订单簿数据，固定 1 秒间隔。支持自动检测市场结算并停止。

```
python3 monitor.py <url1> [url2] ... [选项]
```

| 参数 | 缩写 | 说明 | 默认值 |
|------|------|------|--------|
| `urls` | — | 一个或多个 Polymarket 链接 | — |
| `--duration` | `-d` | 最大录制时长（秒），省略则等到结算 | 无限 |
| `--output` | `-o` | 数据输出目录 | `./data` |

**示例：**

```bash
# 监听单个 BTC 5min 市场 600 秒
python3 monitor.py https://polymarket.com/event/btc-updown-5m-1770965100 -d 600

# 同时监听三个市场直到全部结算
python3 monitor.py \
  https://polymarket.com/event/btc-updown-5m-1770963600 \
  https://polymarket.com/event/btc-updown-5m-1770964200 \
  https://polymarket.com/event/btc-updown-5m-1770964500
```

### 模式 3：`auto_monitor.py` — BTC 5min 自动发现 + 高频采集

全自动：自动发现当前/下一个 BTC 5 分钟市场，使用 50 个并发连接以 ~150 req/s 的速率采集全量订单簿。

```
python3 auto_monitor.py [选项]
```

| 参数 | 缩写 | 说明 | 默认值 |
|------|------|------|--------|
| `--duration` | `-d` | 录制时长（秒） | 300 |
| `--concurrency` | `-c` | 并发连接数 | 50 |
| `--output` | `-o` | 数据输出目录 | `./data` |

**示例：**

```bash
# 默认参数：自动发现，50 并发，5 分钟
python3 auto_monitor.py

# 10 个并发，录制 2 分钟
python3 auto_monitor.py -c 10 -d 120
```

---

## 数据导出与回放

### 导出 replay.json

```bash
python3 main.py export <session_dir>
# 或
python3 export_json.py <session_dir>
```

导出命令**自动检测** session 目录中的 DB schema 类型（recorder / monitor / auto），统一生成相同格式的 `replay.json`。

- **recorder** 数据直接导出
- **monitor** 数据导出全量价位级别
- **auto** 数据自动降采样至 1 fps

### 盘口回放 Player

浏览器打开 `player.html`，拖入 `replay.json` 即可使用。

功能：
- 逐帧播放盘口变化（Bid/Ask 深度条形图）
- 播放速度：0.25x / 0.5x / 1x / 2x / 5x
- 快进、快退、拖动时间轴
- 显示价差、成交量、深度信息
- 键盘快捷键：空格（播放/暂停）、左右箭头（单步）

---

## 目录结构

每次录制在 `data/` 下创建一个 `{slug}_{timestamp}` 格式的文件夹：

```
data/
  btc-updown-5m-1770965100_20260213T063946/
    notes.md          ← 市场信息、录制参数
    ob_data.db        ← SQLite 数据库
    replay.json       ← 导出的回放文件
```

## 三种模式对比

| | record | monitor | auto_monitor |
|---|---|---|---|
| 适用场景 | 任意市场、低频 | 多市场全量盘口 | BTC 5min 高频 |
| 采样频率 | 可配置（默认 5s） | 固定 1s | ~150/s |
| 订单簿范围 | Top-N 档（默认 5） | 全部价位 | 全部价位 |
| 并发模型 | 单线程轮询 | 多线程轮询 | asyncio 50 并发 |
| 成交数据 | WebSocket | WebSocket | WebSocket |
| 自动发现 | 否（需手动 URL） | 否（需手动 URL） | 是（自动发现 BTC 5min） |
| 运行结束条件 | 固定时长 | 结算或超时 | 固定时长 |

## DB Schema 说明

### recorder 模式

**`pm_sports_market_1s`** — 每采样间隔的聚合数据

| 字段 | 类型 | 说明 |
|------|------|------|
| `ts_utc` | TEXT | 时间戳 (UTC) |
| `market_id` | TEXT | 市场 condition ID |
| `best_bid_p` / `best_ask_p` | REAL | 买一/卖一价 |
| `spread` | REAL | 价差 |
| `depth_bid_Nc` / `depth_ask_Nc` | REAL | ±N 分深度 (N=1,5,10,15) |
| `volume_1s` / `trades_1s` | REAL/INT | 成交量/笔数 |

**`pm_sports_orderbook_top5_1s`** — Top-N 档挂单明细

| 字段 | 类型 | 说明 |
|------|------|------|
| `side` | TEXT | `bid` / `ask` |
| `level` | INT | 档位 (1=最优) |
| `price` / `size` | REAL | 价格/数量 |

### monitor 模式

**`pm_sports_market_1s`** — 同上

**`pm_orderbook_full_1s`** — 每秒全量订单簿（所有价位）

**`pm_trades_raw`** — WebSocket 原始成交事件

### auto 模式

**`pm_snapshot`** — 每次 API 请求的快照元数据

| 字段 | 类型 | 说明 |
|------|------|------|
| `snap_id` | INTEGER | 自增主键 |
| `ts_ms` | INTEGER | 毫秒时间戳 |
| `best_bid_p` / `best_ask_p` | REAL | 买一/卖一价 |
| `spread` | REAL | 价差 |
| `bid_levels` / `ask_levels` | INT | 买卖盘层数 |
| `latency_ms` | REAL | API 延迟 |

**`pm_ob_level`** — 全量订单簿（按 snap_id 关联，WITHOUT ROWID）

**`pm_trades_raw`** — WebSocket 成交事件（毫秒时间戳）

---

## 项目文件

| 文件 | 说明 |
|------|------|
| `main.py` | CLI 入口（record + export） |
| `recorder.py` | 通用单市场录制逻辑 |
| `monitor.py` | 多市场全量盘口监听 |
| `auto_monitor.py` | BTC 5min 自动发现 + 高频采集 |
| `resolve.py` | URL 解析 + Gamma API 市场查询 |
| `db.py` | SQLite 建表与写入（recorder 用） |
| `config.py` | API 地址与默认参数 |
| `export_json.py` | SQLite → replay.json 导出（支持全部三种 schema） |
| `player.html` | 浏览器盘口回放播放器 |

## 技术说明

- **数据采集**：REST 轮询订单簿 + WebSocket 监听成交事件，混合方式兼顾深度和实时性
- **市场解析**：自动从 Polymarket URL 解析 slug，通过 Gamma API 获取 token ID 等标识
- **BTC 自动发现**：利用 `btc-updown-5m-{unix_ts}` 的确定性 slug 模式，自动计算当前/下一个 5 分钟窗口
- **存储**：SQLite WAL 模式，轻量无需额外数据库服务
- **高频写入**：auto 模式使用 asyncio Queue 批量写入，支撑 ~150 insert/s
- **回放导出**：自动检测 DB schema，统一导出为 `replay.json`；auto 数据自动降采样至 1fps
- **回放播放器**：纯 HTML/CSS/JS，无需构建工具或后端服务
